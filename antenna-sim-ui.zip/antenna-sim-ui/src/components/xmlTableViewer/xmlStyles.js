export const errorBoxStyle = {
  marginTop: 12,
  padding: "10px 12px",
  borderRadius: 10,
  border: "1px solid #FCA5A5",
  background: "#FEE2E2",
  color: "#991B1B",
  fontSize: 13,
};
